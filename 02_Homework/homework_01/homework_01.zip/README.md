### NOTICE

1. the report has two kind of files: `.docx` & `.pdf`, if you can't open `.docx`, please try `.pdf`

### Question 1:

Question 1 is written in `question_01.py`, please run the program to get the answer (instruction of how to run program is typed in both code comments and word document). Also, there is an sample of answer pasted in `shixin_wang_homework_01.docx` & `shixin_wang_homework_01.pdf` 



### Question 2b:

Question 1 is written in `question_02b.py`, please run the program to get the answer (instruction of how to run program is typed in both code comments and word document). Also, there is an sample of answer pasted in `shixin_wang_homework_01.docx` & `shixin_wang_homework_01.pdf` 